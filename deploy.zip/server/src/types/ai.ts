// server/src/types/ai.ts

export interface AISummary {
  id: string;
  applicationId: string;
  summary: string;
  createdAt: number;
}
