// server/src/types/index.ts
export interface User {
  id: string;
  email: string;
  role: string;
}
