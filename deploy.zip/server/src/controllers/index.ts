// server/src/controllers/index.ts

export * from "./applicationsController.js";
export * from "./documentsController.js";
export * from "./lendersController.js";
export * from "./notificationsController.js";
export * from "./authController.js";
export * from "./aiController.js";
